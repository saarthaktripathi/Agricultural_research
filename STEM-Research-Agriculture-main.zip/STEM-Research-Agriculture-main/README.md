# STEM-Research-Agriculture

All graphs are at 200 DPI but can be plotted at a custom DPI.

## Disclaimer

I would like to clarify that while the code in my repository is related to research in the field of agriculture, my primary intention is to showcase my coding skills and projects. While I appreciate any feedback on my code, please understand that it is not intended to be evaluated as a research paper. Rather, I invite you to assess my coding abilities and approach.
